<?php 
$cari=$_GET['cari'];
header("location:barang.php?cari=$cari");
?>