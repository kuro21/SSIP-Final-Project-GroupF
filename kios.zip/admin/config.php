<?php
            $server = "localhost";
            $username = "root";
            $password = "";
            $database = "kios";

            $conn = mysqli_connect($server,$username,$password,$database);
        ?>